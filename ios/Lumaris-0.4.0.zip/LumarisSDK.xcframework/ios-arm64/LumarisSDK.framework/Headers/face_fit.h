#pragma once

#include <cstddef>

#include "vecmath.h"

namespace makeupar {

/**
 * Ports the fitting in FaceMeshModelController.js.
 *
 * The SDK fits `face.glb` in two parts, and both matter:
 *
 *  - A rigid head pose (translation at the eye centre, rotation from an
 *    eye/nose/chin/forehead basis, scale from interpupillary distance) applied
 *    to the mesh's parent. This gives the shaders a stable frame — their view
 *    and normal maths, and the UV sets painted on the model, all assume it.
 *  - Every vertex then set from its corresponding landmark, expressed in that
 *    frame's local space. The model is MediaPipe's own 468-vertex topology, so
 *    vertex i and landmark i are the same point, and the mesh follows the real
 *    face exactly rather than approximating it with a rigid placement.
 *
 * Doing only the first gives a mesh that floats over expressions; doing only
 * the second breaks the space the shaders were authored in.
 */
class FaceFit {
public:
    struct Pose {
        Vec3 translation;
        Mat3 rotation;
        float scale = 1.0f;
    };

    /**
     * @param model_positions the model's own rest positions, used once to
     *   measure its interpupillary distance so the scale is a ratio.
     */
    void SetModel(const float* model_positions, std::size_t vertex_count);

    bool has_model() const { return model_ipd_ > 1e-6f; }

    /**
     * @param landmarks normalized x,y,z triples straight from the tracker
     * @param out_local fitted vertex positions in the pose's local space
     */
    Pose Fit(const float* landmarks, std::size_t vertex_count,
             float width, float height, float* out_local) const;

    /**
     * Mouth openness in 0..1, the `_lipOpen` uniform the lip shader blends its
     * open- and closed-mouth masks with. Ratio of vertical to horizontal lip
     * distance, rescaled so the useful range starts where the lips part.
     *
     * @param landmarks normalized landmarks, not the fitted positions: the SDK
     *   passes calculateLipOpen the raw MediaPipe array and measures in that
     *   space, so the ratio only matches if we do the same.
     */
    static float ComputeLipOpen(const float* landmarks, std::size_t vertex_count);

    /**
     * Area-weighted vertex normals for the fitted mesh.
     *
     * The SDK calls computeVertexNormals() after every fit, and the lip shader
     * leans on the result: its gradient term reflects the view direction about
     * the surface normal. Rest normals belong to the model's neutral shape, so
     * reusing them leaves the shading describing a face that is not there.
     */
    static void ComputeNormals(const float* positions, std::size_t vertex_count,
                               const unsigned short* indices, std::size_t index_count,
                               float* out_normals);

    /**
     * Normalized landmark to the SDK's scene space.
     *
     * The depth scale is a parameter because the SDK does not use one value:
     * FaceMeshModelController's normalizedToWorld defaults to 100, while
     * FaceNurbsModelController's landmarkToWorld defaults to 200. The eye
     * surfaces are therefore built twice as deep as the face mesh, and matching
     * that is the difference between eyeliner following the lid's curvature and
     * eyeliner lying flat across it.
     */
    static Vec3 LandmarkToWorld(const float* landmarks, int index, float width, float height,
                                float depth_scale = kFaceDepthScale) {
        return NormalizedToWorld(landmarks, index, width, height, depth_scale);
    }

    /** normalizedToWorld's default in FaceMeshModelController.js. */
    static constexpr float kFaceDepthScale = 100.0f;

    /** landmarkToWorld's default in FaceNurbsModelController.js. */
    static constexpr float kEyeDepthScale = 200.0f;

private:
    /** Landmark indices the pose basis is built from. */
    static constexpr int kRightEye = 33;
    static constexpr int kLeftEye = 263;
    static constexpr int kChin = 152;
    static constexpr int kForehead = 10;

    static Vec3 NormalizedToWorld(const float* landmarks, int index, float width, float height,
                                  float depth_scale);

    float model_ipd_ = 0.0f;
};

}  // namespace makeupar
