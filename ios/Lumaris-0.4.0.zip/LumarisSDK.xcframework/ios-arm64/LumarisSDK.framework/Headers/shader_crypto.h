#ifndef OPENMAKEUP_SHADER_CRYPTO_H
#define OPENMAKEUP_SHADER_CRYPTO_H

#include <cstdint>
#include <string>

namespace makeupar {

// AŞAMA 2b (2026-09-05, Murat: "banuba gibi yapıcaz" / production'a çıkmadan
// önce shader'ları gerçekten koru) — shader kaynaklarını (assets/shaders/**/
// *.glsl) APK'dan doğrudan `unzip` ile okunamaz hale getirmek için.
//
// Format (encrypt_shaders.c'nin ürettiği .glsl.enc dosyaları ile bire bir
// eşleşmeli): ilk 16 byte AES-CTR IV'si (her dosya için ayrı, rastgele —
// "aynı anahtarla IV asla tekrar edilmemeli" kuralına uyuyor), geri kalanı
// ciphertext (CTR modunda plaintext ile AYNI uzunlukta, padding yok).
//
// Anahtar burada VE encrypt_shaders.c'de birebir aynı olmalı (offline aracın
// kendisi uygulamaya hiç girmiyor, sadece ÜRETTİĞİ .enc dosyaları giriyor).
//
// DecryptShaderAsset başarısız olursa (yanlış/bozuk giriş, ileride anahtar
// rotasyonu vb.) çağıran taraf (MakeupLayer.kt) düz-metin .glsl asset'ine
// düşüyor — bu fonksiyonun kendisi hiçbir zaman makyaj özelliğini kıramaz,
// sadece koruma sağlayıp sağlamadığını belirler.
bool DecryptShaderAsset(const uint8_t* encrypted, size_t encrypted_len, std::string* out_plaintext);

}  // namespace makeupar

#endif  // OPENMAKEUP_SHADER_CRYPTO_H
