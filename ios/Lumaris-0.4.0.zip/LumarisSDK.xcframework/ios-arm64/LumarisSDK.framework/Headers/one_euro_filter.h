#pragma once

#include <cstddef>
#include <vector>

namespace makeupar {

/**
 * One Euro Filter (Casiez, Roussel, Vogel 2012).
 *
 * Replaces the 23-line Kalman filter the web SDK used. The problem with a
 * fixed-strength smoother is that it can only trade one artefact for the
 * other: enough smoothing to kill jitter while the face is still is enough
 * smoothing to visibly lag a head turn. One Euro adapts — its cutoff rises
 * with measured speed, so it filters hard when nothing is moving and gets out
 * of the way when something is.
 *
 * Lives in C++ rather than Kotlin because it runs over 478 landmarks on every
 * result; the point is a hot path with no allocation and no GC involvement.
 */
class OneEuroFilter {
public:
    struct Params {
        float min_cutoff = 1.0f;  // lower = smoother when still
        float beta = 0.007f;      // higher = more responsive when moving
        float d_cutoff = 1.0f;    // cutoff for the speed estimate itself
    };

    void Configure(const Params& params) { params_ = params; }
    const Params& params() const { return params_; }

    /** Drops all history; the next sample is passed through untouched. */
    void Reset();

    /**
     * Filters `count` values in place-ish: reads `in`, writes `out`.
     * `timestamp_s` must increase; the first call initialises state.
     */
    void Filter(const float* in, float* out, std::size_t count, double timestamp_s);

private:
    struct Channel {
        float value = 0.0f;
        float derivative = 0.0f;
        bool initialised = false;
    };

    static float Alpha(float cutoff, float dt);

    Params params_;
    std::vector<Channel> channels_;
    double last_timestamp_s_ = 0.0;
    bool has_previous_ = false;
};

}  // namespace makeupar
