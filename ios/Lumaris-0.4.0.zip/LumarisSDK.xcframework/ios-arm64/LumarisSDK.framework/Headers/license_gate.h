// Whether this process holds a valid entitlement -- kept here, in native
// memory, rather than as a Kotlin boolean.
//
// ## Why this file exists
//
// Verifying the signature in C++ (license_verify.cpp) stops an attacker
// *forging* a licence. It does nothing about an attacker who simply never
// asks. Before this file, the gate read:
//
//     if (!LicenseManager.isLicensed) { log(...); return }
//
// which compiles to one dex instruction. Taken from our own release APK:
//
//     006a: invoke-virtual {v0}, LicenseManager;.isLicensed:()Z
//     0070: if-nez v0, 007d          <- bytes 39 00 0d 00
//
// Changing 0x39 to 0x28 removes the gate. Two bytes, in a hex editor, with
// no decompiler and no understanding of anything. The helpful error string
// sitting immediately after it made the instruction findable with `strings`.
//
// So the flag moved to where the pipeline actually is. `LicenseGate::Allow`
// is set only by a signature verification that succeeded, inside the same
// library that does the verifying, and `nativeInit` refuses to build a
// pipeline without it. Removing the check now means patching a stripped
// native library rather than reading Kotlin method names out of a dex.
//
// ## What this is still not
//
// Not tamper-proof. A determined reverse engineer with the .so can find
// this and patch it, and no scheme anywhere prevents that. What it changes
// is who can: from anyone with a hex editor and a grep, to someone who can
// work through ARM64 without symbols.
//
// The measure that would go further -- deriving part of the shader
// decryption key from the entitlement, so that removing the check yields
// broken shaders rather than working makeup -- is a separate job. The
// protocol already carries a `keyMaterial` field for it.

#ifndef LUMARIS_LICENSE_GATE_H
#define LUMARIS_LICENSE_GATE_H

#include <cstddef>
#include <cstdint>
#include <string>

namespace lumaris {

/**
 * Records that a grant was verified, and until when.
 *
 * Called only from VerifyLicenseDocument, only after crypto_sign_open has
 * returned success. There is deliberately no other way to set it -- an
 * exported "mark as licensed" entry point would be exactly the single
 * instruction this file exists to remove.
 *
 * @param payload_json  the verified payload; expiry is read from it here
 *                      rather than passed in, so nothing outside this
 *                      library gets to choose the expiry.
 */
void NoteVerifiedGrant(const std::string &payload_json);

/** Drops any recorded grant. Called when a signed denial arrives. */
void ClearGrant();

/** Length of the shader key material carried in a grant. */
constexpr size_t kShaderKeyMaterialLen = 32;

/**
 * Copies out the shader key material from the current grant.
 *
 * This is the half of the shader decryption key that does not ship in the
 * APK. Without a verified, unexpired grant there is nothing to copy, and
 * shader_crypto has no key to build -- so removing the licence check
 * yields shaders that do not decrypt rather than makeup that works.
 *
 * @return false if no grant is currently held.
 */
bool CopyShaderKeyMaterial(uint8_t out[kShaderKeyMaterialLen]);

/**
 * Supplies the shader key material after the host has opened it.
 *
 * Needed because the material is no longer carried in the clear inside the
 * payload -- it arrives sealed to this installation's hardware key, and
 * only the platform keystore can open it, which is a Java API this library
 * cannot call.
 *
 * Refused unless a grant is currently held, so this is not a way to license
 * an unlicensed process. It is also not a hole in the sense the licensed
 * flag would be: wrong bytes here do not unlock anything, they derive a
 * wrong key and produce shaders that do not compile. Only the correct 32
 * bytes are useful, and obtaining those is the problem sealing exists to
 * make hard.
 */
bool SetShaderKeyMaterial(const uint8_t material[kShaderKeyMaterialLen]);

/**
 * @return true only if a grant was verified in this process and has not
 *   expired.
 *
 * Expiry is checked against this library's own clock reading, not against a
 * timestamp handed in from Kotlin -- a caller that supplies "now" is a
 * caller that can supply 1970.
 */
bool IsLicensed();

}  // namespace lumaris

#endif  // LUMARIS_LICENSE_GATE_H
