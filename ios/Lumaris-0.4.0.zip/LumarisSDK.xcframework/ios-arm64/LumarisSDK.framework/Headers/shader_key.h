// Derives the shader decryption key from two halves that never meet outside
// this function.
//
// One half is compiled into the library. The other arrives only inside a
// signature-verified entitlement. Neither alone decrypts anything.
//
// Why this exists: before it, the AES key was a constant in
// shader_crypto.cpp, so every licence check in the SDK was a branch that
// could be removed without consequence -- strip the check and the shaders
// still decrypt and the makeup still works. With the key split, removing
// the check produces shaders that do not compile. The check stops being a
// skippable `if` and becomes an input the renderer needs.
//
// It does not make anything unbreakable, and the limit is worth stating
// plainly: the material must reach every licensed device, so anyone holding
// a valid licence can extract it once from their own process. What it costs
// them is no longer two bytes in a hex editor -- it is obtaining a real
// licence under their own name, and then patching a stripped native library
// to inject a captured constant. That is a different population of people.
//
// Shared by the SDK and by tools/encrypt_shaders.c, compiled from this one
// file in both, so the encryptor and the decryptor cannot drift.

#ifndef LUMARIS_SHADER_KEY_H
#define LUMARIS_SHADER_KEY_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LUMARIS_SHADER_KEY_LEN 32
#define LUMARIS_SHADER_MATERIAL_LEN 32

/**
 * out = SHA-512(embedded_seed || material)[0..32]
 *
 * SHA-512 because TweetNaCl already provides it (crypto_hash) and this
 * library already links TweetNaCl for Ed25519 -- adding a second hash
 * implementation to save 32 bytes of output would be a worse trade than
 * truncating one that is already here and already scrutinised.
 */
void LumarisDeriveShaderKey(const uint8_t material[LUMARIS_SHADER_MATERIAL_LEN],
                            uint8_t out_key[LUMARIS_SHADER_KEY_LEN]);

#ifdef __cplusplus
}
#endif

#endif  // LUMARIS_SHADER_KEY_H
