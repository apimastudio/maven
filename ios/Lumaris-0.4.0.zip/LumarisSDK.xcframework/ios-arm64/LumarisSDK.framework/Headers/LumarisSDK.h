// The framework's umbrella header.
//
// One header, and it is the C bridge -- the same boundary the JNI entry
// points draw on Android. Everything else is implementation: the C++ that
// verifies the licence and decrypts the shaders compiles into the binary and
// ships with no header a customer could read it from.

#import <Foundation/Foundation.h>

#import "lumaris_bridge.h"

FOUNDATION_EXPORT double LumarisSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char LumarisSDKVersionString[];
