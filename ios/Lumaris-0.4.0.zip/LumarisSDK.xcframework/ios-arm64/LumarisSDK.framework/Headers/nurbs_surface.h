#pragma once

#include <cstddef>
#include <vector>

#include "vecmath.h"

namespace makeupar {

/**
 * B-spline surface evaluation, ported from `FaceNurbsModelController.js`.
 *
 * The SDK builds the eyeliner and mascara surfaces this way rather than reusing
 * face.glb: a grid of control points taken straight from landmarks around the
 * eye, evaluated into a smooth sheet. Both categories share the same two
 * surfaces, one per eye, and differ only in material and depth.
 *
 * three.js's NURBSSurface is a rational surface, but every control point here
 * comes from a Vector3, so all weights are 1 and it reduces to a plain
 * B-spline. Implemented directly because the maths is small and well defined —
 * Cox-de Boor basis functions over a clamped uniform knot vector — and pulling
 * in a CAD kernel for it would be far more code and risk than writing it.
 */
class NurbsSurface {
public:
    /** Sampling resolution the SDK uses: 40 x 10 quads. */
    static constexpr int kResolutionU = 40;
    static constexpr int kResolutionV = 10;

    static constexpr int kVertexCount = (kResolutionU + 1) * (kResolutionV + 1);
    static constexpr int kIndexCount = kResolutionU * kResolutionV * 6;

    /**
     * @param control_points row-major grid, rows_u x cols_v
     * @param out_positions x,y,z per sampled vertex
     * @param out_uvs the SDK writes (v, u), not (u, v) — the surface's texture
     *   runs along the eye rather than across it, and swapping them would rotate
     *   every eyeliner and mascara pattern by ninety degrees.
     */
    static void Evaluate(const Vec3* control_points, int rows_u, int cols_v,
                         float* out_positions, float* out_uvs);

    /** Triangulation of the sample grid; constant, so built once. */
    static void BuildIndices(unsigned short* out_indices);

private:
    /** Degree is capped at 3, as in the SDK's getDegree(). */
    static int Degree(int count) { return count - 1 < 3 ? count - 1 : 3; }

    static void GenerateKnots(int count, int degree, std::vector<float>& out);

    static int FindSpan(int degree, float t, int count, const std::vector<float>& knots);

    static void BasisFunctions(int span, float t, int degree,
                               const std::vector<float>& knots, float* out);
};

}  // namespace makeupar
