#pragma once

#include <cmath>

namespace makeupar {

struct Vec3 {
    float x = 0.0f, y = 0.0f, z = 0.0f;

    Vec3 operator-(const Vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    Vec3 operator+(const Vec3& o) const { return {x + o.x, y + o.y, z + o.z}; }
    Vec3 operator*(float s) const { return {x * s, y * s, z * s}; }
};

inline float Dot(const Vec3& a, const Vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }

inline Vec3 Cross(const Vec3& a, const Vec3& b) {
    return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}

inline float Length(const Vec3& v) { return std::sqrt(Dot(v, v)); }

inline Vec3 Normalize(const Vec3& v) {
    const float len = Length(v);
    return len > 1e-8f ? v * (1.0f / len) : Vec3{};
}

inline float Distance(const Vec3& a, const Vec3& b) { return Length(a - b); }

/** Column-major 3x3, columns are the basis vectors. */
struct Mat3 {
    float m[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};

    static Mat3 FromBasis(const Vec3& x, const Vec3& y, const Vec3& z) {
        Mat3 out;
        out.m[0] = x.x; out.m[1] = x.y; out.m[2] = x.z;
        out.m[3] = y.x; out.m[4] = y.y; out.m[5] = y.z;
        out.m[6] = z.x; out.m[7] = z.y; out.m[8] = z.z;
        return out;
    }

    /** For an orthonormal basis the inverse is the transpose — no solve needed. */
    Mat3 Transposed() const {
        Mat3 out;
        out.m[0] = m[0]; out.m[1] = m[3]; out.m[2] = m[6];
        out.m[3] = m[1]; out.m[4] = m[4]; out.m[5] = m[7];
        out.m[6] = m[2]; out.m[7] = m[5]; out.m[8] = m[8];
        return out;
    }

    Vec3 operator*(const Vec3& v) const {
        return {
            m[0] * v.x + m[3] * v.y + m[6] * v.z,
            m[1] * v.x + m[4] * v.y + m[7] * v.z,
            m[2] * v.x + m[5] * v.y + m[8] * v.z,
        };
    }
};

}  // namespace makeupar
