// The boundary Swift talks to, and the only one.
//
// This is the iOS counterpart of native-lib.cpp's JNI entry points, and it
// is deliberately the same shape: a handful of C functions, each of which
// either does the whole decision inside the library or returns nothing.
//
// Plain C rather than Swift's C++ interop, for two reasons. The C++ core is
// shared verbatim with Android, and it should not grow Swift-shaped
// annotations to please one platform. And a narrow C surface is the same
// discipline the JNI boundary already imposes: whatever crosses here is
// visible in one file, in one place, rather than spread across whichever
// C++ symbols Swift happened to be able to see.
//
// Nothing here is a place to *set* a licence. `lumaris_verify_document` is
// the only way a grant is ever recorded, and it records one only after
// checking a signature against a key compiled into this library.

#ifndef LUMARIS_BRIDGE_H
#define LUMARIS_BRIDGE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Verifies a `<payload>.<signature>` licence document.
 *
 * On success, copies the payload JSON into `out_json` (NUL-terminated) and
 * records the grant for `lumaris_is_licensed`. On any failure -- malformed
 * document, wrong signature, an app id that is not this app -- writes
 * nothing and returns false.
 *
 * @param out_json_capacity  size of `out_json`; the call fails rather than
 *                           truncating if the payload would not fit.
 * @return true only if the document was genuinely signed by Lumaris.
 */
bool lumaris_verify_document(const char *document,
                             char *out_json,
                             size_t out_json_capacity);

/**
 * Whether this process currently holds a verified, unexpired grant.
 *
 * The one question the rest of the SDK asks before doing anything. Expiry
 * is checked against this library's own clock reading, never against a
 * timestamp handed in from Swift -- a caller that supplies "now" is a
 * caller that can supply 1970.
 */
bool lumaris_is_licensed(void);

/** Drops any recorded grant. Called when a signed denial arrives. */
void lumaris_clear_grant(void);

/** Length of the shader key material, in bytes. */
#define LUMARIS_KEY_MATERIAL_LEN 32

/**
 * Supplies the shader key material after the host has opened it.
 *
 * The material arrives from the licence service sealed to this
 * installation's hardware key, and only the platform keychain can open it
 * -- which is why it crosses the boundary in this direction rather than
 * being read out of the payload down here.
 *
 * Refused unless a grant is currently held, so this is not a way to license
 * an unlicensed process. Nor is it the backdoor it superficially resembles:
 * wrong bytes do not unlock anything, they derive a wrong key and produce
 * shaders that will not compile. Only the correct 32 bytes are useful, and
 * obtaining those is the problem sealing exists to make hard.
 */
bool lumaris_set_key_material(const uint8_t *material, size_t length);

/**
 * Decrypts one `.glsl.enc` shader asset.
 *
 * Returns false when there is no current grant, which is the whole point of
 * the arrangement: a build with the licence check patched out reaches this
 * function, gets nothing, and renders nothing.
 *
 * @param out_capacity  the plaintext is at most `length - 16` bytes (the
 *                      leading IV), so a buffer of `length` always fits.
 * @param out_length    receives the plaintext length on success.
 */
bool lumaris_decrypt_shader(const uint8_t *encrypted,
                            size_t length,
                            char *out,
                            size_t out_capacity,
                            size_t *out_length);


/* ------------------------------------------------------------------ *
 * The per-frame landmark pipeline.
 *
 * The C++ behind this is shared verbatim with Android -- the One Euro
 * filter, the NURBS evaluator, the face fit. What differs is the boundary:
 * JNI cannot hand a Kotlin FloatArray to C++ without copying it, so the
 * Android wrapper keeps a set of pre-allocated direct ByteBuffers and
 * shuttles data through them. Swift has no such problem. It can pass a
 * pointer into its own array storage straight through, so the buffer
 * machinery on that side simply does not exist here.
 *
 * An opaque handle rather than a global, because a session owns one and a
 * test may want two.
 * ------------------------------------------------------------------ */

typedef void *lumaris_pipeline_t;

lumaris_pipeline_t lumaris_pipeline_create(void);
void lumaris_pipeline_destroy(lumaris_pipeline_t pipeline);

/** One Euro filter tuning. Lower cutoff is smoother at rest; higher beta is
 *  more responsive in motion. */
void lumaris_pipeline_set_filter_params(lumaris_pipeline_t pipeline,
                                        float min_cutoff, float beta, float d_cutoff);

/** Off leaves raw landmarks held between results -- what the web SDK does,
 *  whose own filter is dead code. On is this SDK's addition, to cover an
 *  inference cadence a browser never had to deal with. */
void lumaris_pipeline_set_smoothing(lumaris_pipeline_t pipeline, bool enabled);

/** @param values x,y,z triples, `count` floats in total. */
void lumaris_pipeline_submit_landmarks(lumaris_pipeline_t pipeline,
                                       const float *values, size_t count,
                                       double timestamp_s);

/** Landmarks estimated for `timestamp_s`, normally later than the newest
 *  result. False when nothing has been submitted yet. */
bool lumaris_pipeline_sample_landmarks(lumaris_pipeline_t pipeline,
                                       float *out, size_t count, double timestamp_s);

/** The model's rest positions, so the fit can scale by inter-pupil ratio. */
void lumaris_pipeline_set_model(lumaris_pipeline_t pipeline,
                                const float *positions, size_t vertex_count);

/** Triangle topology, so normals can be rebuilt from each fit. */
void lumaris_pipeline_set_topology(lumaris_pipeline_t pipeline,
                                   const unsigned short *indices, size_t index_count);

/** One morph target's position deltas, by index. */
void lumaris_pipeline_set_morph_target(lumaris_pipeline_t pipeline, size_t index,
                                       const float *deltas, size_t value_count);

/** Per-target weights, in the order the targets were registered. */
void lumaris_pipeline_set_morph_weights(lumaris_pipeline_t pipeline,
                                        const float *weights, size_t count);

/** One eye's NURBS control grid. Eyeliner and mascara share it. */
void lumaris_pipeline_set_eye_control_indices(lumaris_pipeline_t pipeline, int eye,
                                              const int *indices, size_t count,
                                              int rows, int columns);

/** Fills one eye surface's vertex buffers for this frame. Both outputs need
 *  `lumaris_eye_vertex_count()` vertices: positions are 3 floats each, uvs 2. */
bool lumaris_pipeline_evaluate_eye_surface(lumaris_pipeline_t pipeline, int eye,
                                           float width, float height,
                                           float *out_positions, float *out_uvs);

/**
 * Samples smoothed landmarks and fits the face model in one call.
 *
 * @param out_local   fitted vertex positions in head-pose local space
 * @param out_base    fitted positions *before* morphing -- the face-warp
 *                    shader samples the camera at these and renders at the
 *                    morphed ones, so the image stretches with a reshape
 *                    rather than sliding under it
 * @param out_pose    16 floats, column-major 4x4 with scale folded into the
 *                    basis, ready to hand to GL
 * @param out_lip_open the lip shader's `_lipOpen` uniform
 */
bool lumaris_pipeline_sample_and_fit(lumaris_pipeline_t pipeline, double timestamp_s,
                                     float width, float height,
                                     float *out_local, float *out_base,
                                     float *out_normals, float *out_pose,
                                     float *out_lip_open);

bool lumaris_pipeline_has_data(lumaris_pipeline_t pipeline);
void lumaris_pipeline_reset(lumaris_pipeline_t pipeline);

/** The eye surface's sample grid is a compile-time constant, so its
 *  triangulation is built once rather than per frame. */
size_t lumaris_eye_vertex_count(void);
size_t lumaris_eye_index_count(void);
size_t lumaris_build_eye_indices(unsigned short *out, size_t capacity);

#ifdef __cplusplus
}
#endif

#endif  // LUMARIS_BRIDGE_H
