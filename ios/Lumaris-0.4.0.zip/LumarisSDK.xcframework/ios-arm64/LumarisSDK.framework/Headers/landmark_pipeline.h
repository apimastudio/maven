#pragma once

#include <cstddef>
#include <vector>

#include "face_fit.h"
#include "nurbs_surface.h"
#include "one_euro_filter.h"

namespace makeupar {

/**
 * The per-frame native hot path: everything that runs on every landmark result
 * or every rendered frame lives behind this one object, so Kotlin crosses JNI
 * once per event rather than per landmark.
 *
 * It exists because inference and rendering run at different rates. Measured on
 * the GM 8: inference results arrive at ~8Hz while frames render at ~16fps, so
 * half the rendered frames have no fresh landmarks. Drawing the last known set
 * makes makeup visibly step; this samples a continuous estimate instead.
 */
class LandmarkPipeline {
public:
    void Configure(const OneEuroFilter::Params& params) { filter_.Configure(params); }

    /**
     * Turns smoothing and extrapolation off, leaving raw landmarks held between
     * results.
     *
     * That is what the SDK actually does. Its KalmanFilter2D is dead code —
     * nothing imports it — and MakeupEngine feeds `results.multiFaceLandmarks[0]`
     * straight to updateWithLandmarks, calculateLipOpen and updateFaceNurbsMesh,
     * so the mesh simply stays where the last result put it.
     *
     * Ours filters and predicts because our inference cadence is far below a
     * browser's, and without it the makeup visibly steps. That is a deliberate
     * deviation, not a port — so it needs to be switchable, or there is no way
     * to tell whether it is helping or is itself the reason the mesh does not
     * sit like the reference.
     */
    void SetSmoothing(bool enabled) { smoothing_ = enabled; }

    /**
     * Feeds one inference result. `values` is landmark data as x,y,z triples.
     * Timestamps are seconds and must increase.
     */
    void Submit(const float* values, std::size_t count, double timestamp_s);

    /**
     * Produces landmarks for display at `timestamp_s`, which is normally later
     * than the newest result — the render thread is always ahead of inference.
     *
     * Extrapolates along the last measured velocity to cover that gap, which
     * is what stops the mesh trailing behind a moving face. Extrapolation is
     * capped: past a point, guessing further overshoots on direction changes
     * and looks worse than lagging. (A delay buffer would let this interpolate
     * between two known results instead of guessing — deferred, see
     * docs/PORTING_NOTES.md, because it costs one inference interval of
     * latency and ours is currently ~125ms.)
     *
     * @return false when nothing has been submitted yet.
     */
    bool Sample(float* out, std::size_t count, double timestamp_s) const;

    void Reset();

    std::size_t landmark_value_count() const { return filtered_.size(); }
    bool has_data() const { return has_current_; }

    /** Model rest positions, used once to measure its interpupillary distance. */
    void SetModel(const float* positions, std::size_t vertex_count) {
        fit_.SetModel(positions, vertex_count);
    }

    /** Triangle topology, kept so normals can be rebuilt from each fit. */
    void SetTopology(const unsigned short* indices, std::size_t index_count) {
        indices_.assign(indices, indices + index_count);
    }

    /**
     * Registers one morph target's position deltas. face.glb ships 12, each
     * moving a minority of the 468 vertices.
     */
    void SetMorphTarget(std::size_t index, const float* deltas, std::size_t value_count);

    /** Per-target influence, the weights morphs.js drives from friendly names. */
    void SetMorphWeights(const float* weights, std::size_t count);

    /**
     * Registers one eye's NURBS control grid as landmark indices, row-major.
     * Eyeliner and mascara share these surfaces.
     */
    void SetEyeControlIndices(int eye, const int* indices, std::size_t count,
                              int rows, int columns);

    /**
     * Evaluates one eye surface from the current smoothed landmarks.
     *
     * Sampled in the same world space the face fit produces, so the result
     * goes through the same model matrix and lands with the rest of the face.
     */
    bool EvaluateEyeSurface(int eye, float width, float height,
                            float* out_positions, float* out_uvs) const;

    /**
     * Samples smoothed landmarks and fits the face model to them in one pass,
     * so a rendered frame crosses JNI once rather than once per stage.
     *
     * @param out_local fitted vertex positions in the head-pose local space
     * @param out_pose 16 floats: rotation+translation as a column-major 4x4,
     *   with scale folded into the basis, ready to hand to GL as a uniform
     * @param out_lip_open the `_lipOpen` uniform for the lip shader
     */
    /**
     * @param out_base fitted positions *before* morphing. The face-warp shader
     *   samples the camera at these, then renders at the morphed positions, so
     *   the image stretches with the reshape instead of sliding under it.
     */
    bool SampleAndFit(double timestamp_s, float width, float height,
                      float* out_local, float* out_base, float* out_normals,
                      float* out_pose, float* out_lip_open);

private:
    OneEuroFilter filter_;
    FaceFit fit_;
    std::vector<float> sample_scratch_;
    std::vector<unsigned short> indices_;
    std::vector<std::vector<float>> morph_targets_;
    std::vector<float> morph_weights_;

    struct EyeGrid {
        std::vector<int> indices;
        int rows = 0;
        int columns = 0;
    };
    EyeGrid eyes_[2];

    std::vector<float> filtered_;   // newest filtered result
    std::vector<float> previous_;   // the one before it, for velocity
    std::vector<float> velocity_;   // per-value units per second

    double current_timestamp_s_ = 0.0;
    double previous_timestamp_s_ = 0.0;
    bool smoothing_ = true;
    bool has_current_ = false;
    bool has_previous_ = false;
};

}  // namespace makeupar
