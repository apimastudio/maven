// Entitlement verification: the one place that decides whether a licence
// document actually came from Lumaris.
//
// This lives in C++ rather than in Kotlin for a single reason, and it is the
// only reason: patching a dex file takes minutes with tooling anyone can
// download, while doing the same to a stripped native library is a different
// kind of work. Nothing here is cryptographically stronger for being in C++
// -- the signature check is identical either way. What changes is the cost of
// removing it.
//
// The public key is compiled into this library rather than passed in from
// Kotlin, for the same reason. A key that arrives as an argument is a key an
// attacker can substitute with their own by editing one Kotlin constant, and
// then sign whatever they like. Embedded here, replacing it means editing the
// .so.
//
// This is not, and cannot be, tamper-proof. Anyone holding the APK can strip
// the call site out entirely, and no licensing scheme anywhere solves that.
// The measure that would actually change the economics -- deriving part of
// the shader decryption key from a valid entitlement, so that removing the
// check yields broken shaders rather than working makeup -- is a later job;
// the protocol already carries a `keyMaterial` field for it, currently null.

#ifndef LUMARIS_LICENSE_VERIFY_H
#define LUMARIS_LICENSE_VERIFY_H

#include <cstddef>
#include <string>

namespace lumaris {

/**
 * Verifies a `<base64url payload>.<base64url Ed25519 signature>` document
 * against the embedded public key.
 *
 * The signature covers the *encoded* payload bytes -- the base64url text
 * exactly as transmitted, not the JSON it decodes to. That is deliberate on
 * both sides: verifying a re-serialised JSON object would require the server
 * and every client to agree forever on key order, spacing and unicode
 * escaping, which is a well-known source of signature bugs between
 * independent implementations.
 *
 * @param document  the full `payload.signature` string
 * @param out_json  on success, the decoded payload JSON
 * @return true only if the document is well-formed AND the signature verifies
 */
bool VerifyLicenseDocument(const std::string &document, std::string *out_json);

}  // namespace lumaris

#endif  // LUMARIS_LICENSE_VERIFY_H
