# Third-party attribution — Lumaris iOS SDK

The same record the Android SDK keeps, for the same reason: this is a
compliance obligation, not a build input, and it has to be accurate in
every artifact that ships. Where a row says the file is shared with the
Android SDK, it is literally the same bytes — the port compiles the C
sources rather than reimplementing them.

## Vendored verbatim (upstream code, carried unchanged)

| Upstream | Vendored as | Licence | Why |
|---|---|---|---|
| [kokke/tiny-AES-c](https://github.com/kokke/tiny-AES-c) | `sdk/Sources/LumarisVendored/aes.c`, `include/aes.h` | public domain / Unlicense | Shader asset encryption. Only change from upstream: AES256 enabled. |
| [TweetNaCl](https://tweetnacl.cr.yp.to/) 20140427 | `sdk/Sources/LumarisVendored/tweetnacl.c`, `include/tweetnacl.h` | public domain | Ed25519 verification of licence entitlements. Carried byte-for-byte so it can be re-fetched and diffed against the canonical release; `sha256(tweetnacl.c) = 02e65bc3013ff2168983365e55906bc783c4c7e0a60d8100f17bb303a17175c4`. |

Both are carried unmodified for the same reason as on Android: a
correctness bug in hand-rolled crypto here would not be a weaker lock, it
would be a broken product.

## Derived from OpenMakeupSDK (MIT)

The makeup shaders and the NURBS surface evaluation this SDK renders with
originate in [ehsanwwe/OpenMakeupSDK](https://github.com/ehsanwwe/OpenMakeupSDK),
MIT licensed — verbatim text in `OPENMAKEUPSDK_LICENSE.txt` beside this
file. Per the MIT licence, the copyright notice and permission text are
carried forward.

| Original (OpenMakeupSDK) | In this repository | Status |
|---|---|---|
| `src/core/FaceNurbsModelController.js` (Cox-de Boor NURBS math) | `sdk/Sources/LumarisCore/nurbs_surface.{h,cpp}` | ported (shared with Android) |
| `assets/shaders/**/*.glsl` (8 layers, 16 files) | encrypted assets, decrypted at runtime; compiled through `sdk/Sources/Lumaris/ShaderProgram.swift` | verified compiling on Apple's driver; the shipping asset pipeline is not wired up yet |
| `src/morphs.js` (morph control name → glb target mapping) | not yet ported to iOS | pending |

The shaders reach a device encrypted, which changes nothing about the
attribution obligation: they are still distributed, and the notice above is
what discharges it.

## Not ported

`OpenMakeup.js`, `MakeupEngine.js`, `materials.js`,
`FaceMeshModelController.js` and `faceWarpMaterial.js` are Three.js/DOM
orchestration. Only the underlying technique is carried across, into
Swift/GLES/C++ with a different structure — the same boundary the Android
port drew.
